"""
Author: Davin Strouse
Date: 2/21/2025
Summary: This is a resturant ordering system. It is intended for a restaurant named The Velvet Fork. Users can add the requested meals and it will add up the total. Then it will open a second window for the receipt.

This program uses breezypythongui. You can find more information at https://lambertk.academic.wlu.edu/breezypythongui/
"""

import tkinter as tk
from breezypythongui import EasyFrame, EasyPanel
from tkinter import PhotoImage


class binaryOrder(EasyFrame):

    def __init__(self):
        super().__init__(title="Velvet Fork Ordering System", width=1500, height=750,resizable=False)
        
        # Dataset
        
        self.totalPrice=0.0
        self.currentOrder = {}
        self.addedMeals = {
            'Steak Meal': 19.99,
            'Burger Meal': 9.99,
            'Salmon Meal': 14.99,
            'Soup Meal': 9.99,
            'Lobster Meal': 24.99,
            'Shrimp Meal': 12.99}
        self.meal1 = "A ribeye steak cooked to medium served with french fries and a salad."
        self.meal2 = "A Cheeseburger cooked well done with lettuce, onion, tomato, and pickle. \nServed with french fries."
        self.meal3 = "A seasoned serving of salmon served with vegetable medly and mashed potatos."
        self.meal4 = "A bowl of fresh homemade chicken noodle soup."
        self.meal5 = "Lobster tail served with a side salad"
        self.meal6 = "Shrimp pasta with tomatos and red sauce"
        
        #GUI Panels
        self.setupGUI()
        

        
        
        
        
    def setupGUI(self):
        #Generates Each Panel
        #Top Panel
        self.topPanel = self.addPanel(row=0,column=0,columnspan=3,background="#153363")
        self.topPanel.config(width=1500,height=250, bd= 8, relief="sunken")
        self.topPanel.grid_propagate(False)
        
        #Bottom Panel
        self.bottomPanel = self.addPanel(row=1,column=0,columnspan=3)
        self.bottomPanel.config(width=1500,height=500)
        
        #Food Subpanel
        self.foodPanel = EasyPanel(self.bottomPanel,row=1,column=0,rowspan=1,columnspan=1,background="gray")
        self.foodPanel.config(width=500,height=500,bd=8,relief='sunken')
        self.foodPanel.grid_propagate(False)
        
        #Description Subpanel
        self.descPanel = EasyPanel(self.bottomPanel,row=1,column=1,rowspan=1,columnspan=1,background="#153363")
        self.descPanel.config(width=500,height=500)
        self.descPanel.grid_propagate(False)
        
        #Receipt Subpanel
        self.receiptPanel = EasyPanel(self.bottomPanel,row=1,column=2,rowspan=1,columnspan=1,background="gray")
        self.receiptPanel.config(width=500,height=500,bd=8,relief='sunken')
        self.receiptPanel.grid_propagate(False)
        

        
        
        
        
        

        #Logo picture
        self.logoPhoto = self.addLabel(text="",row=0,column=0,background="#153363")
        self.image = PhotoImage(file="Logo.png",)
        self.logoPhoto["image"] = self.image
        
        
        #Background picture
        self.background = self.topPanel.addLabel(text="",row=0,column=0,background="#153363")
        self.backPhoto = PhotoImage(file='background.png')
        self.background["image"] = self.backPhoto
        
        #Exit Button
        self.exitButton = self.topPanel.addButton(text="Exit",row=0,column=0,command=self.quit)
        self.exitButton.config(font=25,width=20,height=2,borderwidth=2)
        self.exitButton.grid(row=0,column=0,sticky="NE")
        

        


        #Food Panel Buttons and Labels
            #Adds the Steak Button
        self.steakButton = self.foodPanel.addButton(text='Steak Meal',row=0,column=0,columnspan=1, command= lambda:self.mealDetail('Steak Meal'))
        self.foodPanel.addButton(text='Add Meal',row=0,column=1,command= lambda:self.addMeal('Steak Meal'))
        self.steakButton.grid(sticky="W")
        self.steakButton.config(font=("Arial",25))

        #Adds the Burger Button
        self.burgerButton = self.foodPanel.addButton(text='Burger Meal',row=1,column=0,columnspan=1,command= lambda:self.mealDetail('Burger Meal'))
        self.foodPanel.addButton(text='Add Meal',row=1,column=1,command= lambda:self.addMeal('Burger Meal'))
        self.burgerButton.grid(sticky="W")
        self.burgerButton.config(font=("Arial",25))

        #Adds the Salmon Button
        self.salmonButton = self.foodPanel.addButton(text='Salmon Meal',row=2,column=0,columnspan=1,command= lambda:self.mealDetail('Salmon Meal'))
        self.foodPanel.addButton(text='Add Meal',row=2,column=1,command= lambda:self.addMeal('Salmon Meal'))
        self.salmonButton.grid(sticky="W")
        self.salmonButton.config(font=("Arial",25))
        
        #Adds the Soup Button
        self.soupButton = self.foodPanel.addButton(text='Soup Meal',row=3,column=0,columnspan=1,command= lambda:self.mealDetail('Soup Meal'))
        self.foodPanel.addButton(text='Add Meal',row=3,column=1,command= lambda:self.addMeal('Soup Meal'))
        self.soupButton.grid(sticky="W")
        self.soupButton.config(font=("Arial",25))
        
        #Adds the Lobster Button
        self.lobsterButton = self.foodPanel.addButton(text='Lobster Meal',row=4,column=0,columnspan=1,command= lambda:self.mealDetail('Lobster Meal'))
        self.foodPanel.addButton(text='Add Meal',row=4,column=1,command= lambda:self.addMeal('Lobster Meal'))
        self.lobsterButton.grid(sticky="W")
        self.lobsterButton.config(font=("Arial",25))
        
        #Adds the Shrimp Button
        self.shrimpButton = self.foodPanel.addButton(text='Shrimp Meal',row=5,column=0,columnspan=1,command= lambda:self.mealDetail('Shrimp Meal'))
        self.foodPanel.addButton(text='Add Meal',row=5,column=1,command= lambda:self.addMeal("Shrimp Meal"))
        self.shrimpButton.grid(sticky="W")
        self.shrimpButton.config(font=("Arial",25))
        
        
        
        
        #Receipt Area
        self.receiptPanel.addLabel(text='Order',row=0,column=0,columnspan=2,sticky="NEW")
        self.receiptBox = self.receiptPanel.addTextArea(text='',row=1,column=0, columnspan=2,width=1, height=2,)
        self.checkoutButton = self.receiptPanel.addButton(text='Checkout',row=3,column=1,command=self.receiptMenu)
        self.checkoutButton.grid(sticky="SEw")
        self.clearButton = self.receiptPanel.addButton(text="Clear Order", row=3,column=0,command=self.clearOrders)
        self.clearButton.grid(sticky="sew")
        self.receiptPanel.addLabel(text="Total:",row=2,column=0,sticky='sw')
        self.totalLabel = self.receiptPanel.addLabel(text=f'${self.totalPrice:.2f}',row=2, column=1,sticky="se")

        
        
        
    

    
    def addMeal(self, mealName):
        #Adds meals to the textArea in the receipt panel
        if mealName not in self.addedMeals:
            return  # Meal not found in the menu

        price = self.addedMeals[mealName]
        if mealName in self.currentOrder:
            quantity, _ = self.currentOrder[mealName]
            self.currentOrder[mealName] = (quantity + 1, price)
        else:
            self.currentOrder[mealName] = (1, price)

        # Clear the current display
        self.receiptBox.delete(1.0, tk.END)

        # Redisplay all items
        for meal, (quantity, price) in self.currentOrder.items():
            self.receiptBox.insert(tk.END, f"{meal:<20} x{quantity:<2} ${price * quantity:>6.2f}\n")

    # Update the total price
        self.totalPrice = sum(quantity * price for quantity, price in self.currentOrder.values())
        self.totalLabel.config(text=f'${self.totalPrice:.2f}')
    
    def mealDetail(self, mealName):
        #Adds the contents of the Description Panel
        pickMeal = {
        'Steak Meal': [self.meal1],
        'Burger Meal': [self.meal2],
        'Salmon Meal': [self.meal3],
        'Soup Meal': [self.meal4],
        'Lobster Meal': [self.meal5],
        'Shrimp Meal': [self.meal6]
        }
        

        mealDesc=pickMeal[mealName]
        self.descPanel.addLabel(text=[mealName],row=2,column=0,sticky="EW")
        try:
            self.descript.destroy()
        except AttributeError:
            pass
        self.descript = self.descPanel.addLabel(text=mealDesc, row=3,column=0,sticky="ew")
        
        #Assigns the correct picture based on the meal
        if mealName == 'Steak Meal':    
            self.descPhoto = self.descPanel.addLabel(text="",row=0,column=0,sticky="EW",background="#153363")
            self.mealPhoto = PhotoImage(file='steak.png')
            self.mealPhoto.config
            self.descPhoto.grid(sticky='ew')
            self.descPhoto["image"] = self.mealPhoto
        elif mealName == 'Burger Meal':    
            self.descPhoto = self.descPanel.addLabel(text="",row=0,column=0,sticky="EW",background="#153363")
            self.mealPhoto = PhotoImage(file='burger.png')
            self.descPhoto["image"] = self.mealPhoto
        elif mealName == 'Salmon Meal':    
            self.descPhoto = self.descPanel.addLabel(text="",row=0,column=0,sticky="EW",background="#153363")
            self.mealPhoto = PhotoImage(file='salmon.png')
            self.descPhoto["image"] = self.mealPhoto 
        elif mealName == 'Soup Meal':    
            self.descPhoto = self.descPanel.addLabel(text="",row=0,column=0,sticky="EW",background="#153363")
            self.mealPhoto = PhotoImage(file='soup.png')
            self.descPhoto["image"] = self.mealPhoto
        elif mealName == 'Lobster Meal':    
            self.descPhoto = self.descPanel.addLabel(text="",row=0,column=0,sticky="EW",background="#153363")
            self.mealPhoto = PhotoImage(file='lobster.png')
            self.descPhoto["image"] = self.mealPhoto
        elif mealName == 'Shrimp Meal':    
            self.descPhoto = self.descPanel.addLabel(text="",row=0,column=0,sticky="EW",background="#153363")
            self.mealPhoto = PhotoImage(file='shrimp.png')
            self.descPhoto["image"] = self.mealPhoto
           
        
        
    
    
    
    
    def receiptMenu(self):
        #Generates the receipt window
        receiptWindow = tk.Toplevel(self)
        receiptWindow.title("Receipt")
        receiptWindow.geometry("400x600")
        tk.Label(receiptWindow, text="Order Receipt", font=16,).pack(pady=10)
        itemsFrame = tk.Frame(receiptWindow)
        itemsFrame.pack(fill='both',expand=True,padx=10,pady=10)
        #Fills second window 
        for item, (quantity, price) in self.currentOrder.items():
            itemLabel = tk.Label(itemsFrame,text=f"{item} x{quantity}", anchor="w")
            itemLabel.pack(fill="x")
            priceLabel = tk.Label(itemsFrame, text=f"${price * quantity:.2f}",anchor="e")
            priceLabel.pack(fill="x")

        

        
        total = tk.Label(receiptWindow,text=f"Total: ${self.totalPrice:.2f}",font='14',pady=3)
        total.pack(fill='x')
        thanks = tk.Label(receiptWindow,text="Thank you For Dining At \n The Velvet Fork",font= 16,anchor='s')
        thanks.pack(fill='x')

    def clearOrders(self):
        #Removes the current contents of the receipt panel
        for widget in self.receiptPanel.winfo_children():
        
            widget.destroy()

        self.currentOrder.clear()
        
        self.receiptPanel.addLabel(text='Order',row=0,column=0,columnspan=2,sticky="NEW")
        self.receiptBox = self.receiptPanel.addTextArea(text='',row=1,column=0, columnspan=2,width=1, height=2,)
        self.checkoutButton = self.receiptPanel.addButton(text='Checkout',row=3,column=1,command=self.receiptMenu)
        self.checkoutButton.grid(sticky="SEw")
        self.clearButton = self.receiptPanel.addButton(text="Clear Order", row=3,column=0,command=self.clearOrders)
        self.clearButton.grid(sticky="sew")
        self.receiptPanel.addLabel(text="Total:",row=2,column=0,sticky='sw')
        self.totalPrice = 0.0

        self.totalLabel = self.receiptPanel.addLabel(text=f'${self.totalPrice:.2f}',row=2, column=1,sticky="se")
        
        


        




binaryOrder().mainloop()